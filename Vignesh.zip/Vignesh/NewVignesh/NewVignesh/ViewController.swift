import UIKit

class ViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    // MARK: - Properties
    var tableSource = [String]()
    
    // MARK: - Actions
    @IBAction func pickDateButtonTouched(_ sender: Any) {
        // a bit contrived, but you get the idea
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        // get the date
        let dateString = formatter.string(from: datePicker.date)
        // put the string in the data source for the table
        tableSource.insert(dateString, at: 0)
        table.reloadData()
        // profit?
    }
    
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        table.dataSource = self
    }
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = tableSource[indexPath.row]
        return cell
    }
}
