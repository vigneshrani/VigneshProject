//
//  ViewController.swift
//  Notification
//
//  Created by thomas on 20/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    @IBAction func Button(_ sender: Any) {
        
        
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Remainder"
        content.body = "vignesh you  set  a  Notification"
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(identifier: "remainder",content: content, trigger:trigger)
        center.add(request) {(error) in
            if error != nil {
                print("error local notification")
                
            }
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        
    }


}

