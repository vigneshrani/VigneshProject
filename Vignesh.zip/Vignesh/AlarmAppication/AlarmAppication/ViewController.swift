//
//  ViewController.swift
//  AlarmAppication
//
//  Created by thomas on 20/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit
import EventKit

class ViewController: UIViewController {

    
    let notification = UILocalNotification()
    
    /* Time and timezone settings */
    notification.firstDate = NSDate(timeIntervalSinceNow: 8.0)
    notification.repeatInterval = NSCalendarUnit.Day
    notification.timeZone = NSCalendar.currentCalendar().timeZone
    notification.alertBody = "A new item is downloaded."
    
    /* Action settings */
    notification.hasAction = true
    notification.alertAction = "View"
    
    /* Badge settings */
    notification.applicationIconBadgeNumber =
    UIApplication.sharedApplication().applicationIconBadgeNumber + 1
    /* Additional information, user info */
    notification.userInfo = [
    "Key 1" : "Value 1",
    "Key 2" : "Value 2"
    ]
    
    /* Schedule the notification */
    UIApplication.sharedApplication().scheduleLocalNotification(notification)

override func viewDidLoad() {
    super.viewDidLoad()
    
    // Do any additional setup after loading the view, typically from a nib.
}
}

//    @IBAction func AddEvent(_ sender: Any) {
//        let eventStore:EKEventStore = EKEventStore()
//        eventStore.requestAccess(to: .event) {
//            (granted, error) in
//        if (granted) && (error == nil)
//        {
//            print("granted  \(granted)")
//            print("error \(error)")
//            let event:EKEvent = EKEvent(eventStore: eventStore)
//            event.title = "add event testing title"
//            event.startDate = Date()
//            event.endDate = Date()
//            event.notes = "this is note"
//            event.calendar = eventStore.defaultCalendarForNewEvents
//            do{
//                try eventStore.save(event, span: .  thisEvent)
//            }catch let     error as NSError
//            {
//                print("error : \(error)")
//            }
//            print("Save Event")
//
//
//        }else{
//            print("error : \(error)")
//
//            }
//
//        }
//    }
    


