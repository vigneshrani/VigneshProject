
import UIKit
import UserNotifications

class ViewController: UIViewController {
    
    // IBOutlet goes here
    @IBOutlet var myDatePicker: UIDatePicker!
    @IBOutlet var mySwitch: UISwitch!

    
    // let = whatever goes here
    // var = whatever goes here
    var localNotification = UILocalNotification()   // You just need one
    var notificationsCounter = 0
    
    // put your functions now
    func datePicker()            { myDatePicker.datePickerMode = UIDatePicker.Mode.date }
    func datePickerDefaultDate() { myDatePicker.date = NSDate().xDays(+1)              }
    func notificationsOptions()  {
        localNotification.timeZone = NSTimeZone.local
        localNotification.repeatInterval = .CalendarUnitDay
        UIApplication.shared.scheduleLocalNotification(localNotification)
        localNotification.alertAction = "Open App"
        localNotification.alertBody = "Here is the seven o'clock notification"
        localNotification.soundName = UILocalNotificationDefaultSoundName
        localNotification.applicationIconBadgeNumber = UIApplication.shared.applicationIconBadgeNumber + 1
        //     you may add arbitrary key-value pairs to this dictionary.
        //     However, the keys and values must be valid property-list types
        //     if any are not, an exception is raised.
        // localNotification.userInfo = [NSObject : AnyObject]?
    }
    func toggleSwitch(){
        if mySwitch.isOn{
            localNotification.fireDate = myDatePicker.date.fireDate  // combined date = picked Date + 7:00am time
        } else {
            localNotification.fireDate = NSDate(timeIntervalSinceNow: 999999999999) as Date   // will never be fired
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        datePicker()
        datePickerDefaultDate()
        notificationsOptions()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // here is where you place your IBActions
    
    @IBAction func switchPressed(sender: AnyObject) {
        toggleSwitch()
        
    }
}
