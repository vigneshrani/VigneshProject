import UIKit
import UserNotifications
import UserNotificationsUI

class ViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var datePickerView:: UIDatePicker!
    @IBOutlet weak var txtDatePicker: UITextField!
    let datePicker = UIDatePicker()
    let requestIdentifier = "prem"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func showDatePicker(_ textField : UITextField){
        //Formate Date
        datePicker.frame = CGRect.init(x: 0, y: 30, width: datePickerView.bounds.width, height: datePickerView.bounds.height-50)
        datePicker.datePickerMode = .dateAndTime
        
        txtDatePicker.inputView = self.datePicker
        
        
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.frame = CGRect.init(x: 0, y: 0, width: datePickerView.bounds.width, height: 30)
        toolbar.backgroundColor = UIColor.blue
        //        toolbar.sizeToFit()
        
        //done button & cancel button
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(ViewController.donedatePicker))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.done, target: self, action: #selector(ViewController.cancelDatePicker))
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        //datePickerView.addSubview(toolbar)
        txtDatePicker.inputAccessoryView = toolbar
        
        
        
        
    }
    
    @objc func donedatePicker(){
        //For date formate
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        txtDatePicker.text = formatter.string(from: datePicker.date)
        //dismiss date picker dialog
        txtDatePicker.resignFirstResponder()
        
    }
    
    
    @objc func cancelDatePicker(){
        txtDatePicker.resignFirstResponder()
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.showDatePicker(self.txtDatePicker)
    }
    
    @IBAction func triggerButton(_ sender: Any) {
        
        print("Notification will be triggered in 2 sec. Hold on...")
        let content = UNMutableNotificationContent()
        content.title = "Intro to Notifications"
        content.subtitle = "Hello"
        content.body = "I learnt local notification"
        content.sound = UNNotificationSound.default
        
        //Delivering the notification in two seconds.
        let triggerDate = Calendar.current.dateComponents([.year,.month,.day,.hour,.minute,.second,], from: datePicker.date)
        let trigger = UNCalendarNotificationTrigger.init(dateMatching: triggerDate, repeats: false)
        let request = UNNotificationRequest(identifier: requestIdentifier, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().delegate = self as UNUserNotificationCenterDelegate
        UNUserNotificationCenter.current().add(request){(error) in
            
            if (error != nil){
                
                print(error?.localizedDescription as Any )
            }
        }
        
    }
    
    
    @IBAction func stopButton(_ sender: Any) {
        print("Remove pending request.")
        let centre = UNUserNotificationCenter.current()
        centre.removePendingNotificationRequests(withIdentifiers: [requestIdentifier])
        
    }
}




extension ViewController: UNUserNotificationCenterDelegate {
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        print("Tapped in notification")
    }
    
    //This is key callback to present notification while the app is in foreground
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        print("Notification being triggered")
        //You can either present alert ,sound or increase badge while the app is in foreground too with ios 10
        //to distinguish between notifications
        if notification.request.identifier == requestIdentifier{
            
            completionHandler( [.alert,.sound,.badge])
            
        }
    }
    
}

