import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var dateField: UITextField!
    
    @IBAction func dateField(sender: UITextField) {
        
        let datePickerView  : UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePicker.Mode.time
        sender.inputView = datePickerView
        datePickerView.addTarget(self, action: Selector(("handleDatePicker:")), for: UIControl.Event.valueChanged)
        
    }
    @IBAction func DoneButton(sender: UIButton) {
        dateField.resignFirstResponder()
        //How to make datepicker disappear???
    }
    
    func handleDatePicker(sender: UIDatePicker) {
        let timeFormatter = DateFormatter()
        dateField.text = timeFormatter.string(from: sender.date)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
}
