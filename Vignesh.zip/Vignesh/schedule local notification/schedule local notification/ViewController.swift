//
//  ViewController.swift
//  schedule local notification
//
//  Created by Apoorv Mote on 18/10/15.
//  Copyright © 2015 Apoorv Mote. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var button: UIButton!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 9
        updateUI()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func savePressed(sender: UIButton) {
        // 1
        let notification = UILocalNotification()
        // 15
        notification.fireDate = fixedNotificationDate(dateToFix: datePicker?.date as! NSDate)
        // 3
        if textField.text == "" {
            
            notification.alertBody = "New blog is posted at blog.apoorvmote.com"
            
        }
        else {
            
            notification.alertBody = textField.text
            
        }
        // 4
        notification.timeZone = NSTimeZone.defaultTimeZone
        // 5
        notification.repeatInterval = NSCalendarUnit.Minute
        // 6
        notification.applicationIconBadgeNumber = 1
        // 7
        UIApplication.sharedApplication().scheduleLocalNotification(notification)
        
    }
    // 14
    func fixedNotificationDate(dateToFix: NSDate) -> NSDate {
        
        let dateComponents: NSDateComponents = NSCalendar.currentCalendar().components([NSCalendarUnit.Day, NSCalendarUnit.Month, NSCalendarUnit.Year, NSCalendarUnit.Hour, NSCalendarUnit.Minute], fromDate: dateToFix)
        
        dateComponents.second = 0
        
        let fixedDate: NSDate = NSCalendar.currentCalendar().dateFromComponents(dateComponents)!
        
        return fixedDate
        
    }
    
    // 8
    func updateUI() {
        
        let currentSettings = UIApplication.sharedApplication().currentUserNotificationSettings()
        
        if currentSettings?.types != nil {
            
            if currentSettings!.types == [UIUserNotificationType.Badge, UIUserNotificationType.Alert] {
                
                textField.hidden = false
                
                button.hidden = false
                
                datePicker.hidden = false
                
            }
            else if currentSettings!.types == [UIUserNotificationType.Badge] {
                
                textField.hidden = true
                
            }
            else if currentSettings!.types == UIUserNotificationType.None {
                
                textField.hidden = true
                
                button.hidden = true
                
                datePicker.hidden = true
                
            }
            
        }
        
    }


}

