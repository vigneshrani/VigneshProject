//
//  ViewController.swift
//  json2demoget
//
//  Created by Yogesh Patel on 23/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit
import Alamofire
struct jsonstruct:Decodable {
    let name:String
    let capital:String
    let alpha2Code:String
    let alpha3Code:String
    let region:String
    let subregion:String
    
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var tableview: UITableView!
    
    
    var arrdata = [jsonstruct]()
    override func viewDidLoad() {
        super.viewDidLoad()
        getdata()
    }
    
    func getdata(){
        let todoEndpoint: String = "https://restcountries.eu/rest/v2/all"
        Alamofire.request(todoEndpoint)
            .responseJSON { response in
                // check for errors
                guard response.result.error == nil else {
                    // got an error in getting the data, need to handle it
                    print("error calling GET on /todos/1")
                    print(response.result.error!)
                    return
                }
                print("my data",response.result.value )
//                do{if response.result.error == nil{
//                    self.arrdata = response.result.value
//
//                    for mainarr in self.arrdata{
//                        //print(mainarr.name,":",mainarr.capital,":",mainarr.alpha3Code)
//                        DispatchQueue.main.async {
//                            self.tableview.reloadData()
//                        }
//
//                    }
//                    }
//
//                }catch{
//                    print("Error in get json data")
//                }
                // make sure we got some JSON since that's what we expect
                guard let json = response.result.value as? [String: Any] else {
                    print("didn't get todo object as JSON from API")
                    if let error = response.result.error {
                        print("Error: \(error)")
                    }
                    return
                }

                // get and print the title
                guard let todoTitle = json["title"] as? String else {
                    print("Could not get todo title from JSON")
                    return
                }
                print("The title is: " + todoTitle)
        }
//        let url = URL(string: "https://restcountries.eu/rest/v2/all")
//        URLSession.shared.dataTask(with: url!) { (data, response, error) in
//            do{if error == nil{
//                self.arrdata = try JSONDecoder().decode([jsonstruct].self, from: data!)
//                print("my datra",self.arrdata)
//                for mainarr in self.arrdata{
//                    //print(mainarr.name,":",mainarr.capital,":",mainarr.alpha3Code)
//                    DispatchQueue.main.async {
//                            self.tableview.reloadData()
//                    }
//
//                }
//                }
//
//            }catch{
//                print("Error in get json data")
//            }
//
//            }.resume()
    }
    
    
    //TableView
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrdata.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.iblname.text = "Name : \(arrdata[indexPath.row].name)"
        cell.iblcapital.text = "Capital : \(arrdata[indexPath.row].capital)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detail:DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "detail") as! DetailViewController
        detail.strregion = "Region :\(arrdata[indexPath.row].region)"
        detail.strsubregion = "SubRegion :\(arrdata[indexPath.row].subregion)"
        detail.stralpha3 = "Alpha3code :\(arrdata[indexPath.row].alpha3Code)"
        detail.stralpha2 = "Alpha2code :\(arrdata[indexPath.row].alpha2Code)"
        self.navigationController?.pushViewController(detail,animated: true)
        
        
    }
    
}


