//
//  TableViewCell.swift
//  VigJson
//
//  Created by thomas on 22/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var iblcapital: UILabel!
    
    @IBOutlet weak var iblname: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
