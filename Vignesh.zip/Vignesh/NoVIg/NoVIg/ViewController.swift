//
//  ViewController.swift
//  NoVIg
//
//  Created by thomas on 20/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit
import UserNotifications
import Foundation


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBOutlet weak var myDatePicker: UIDatePicker!
    
    @IBOutlet weak var mySwitch: UISwitch!
    var localNotification = UILocalNotification()   // You just need one
    var notificationsCounter = 0
    
    // put your functions now
    func datePicker()            { myDatePicker.datePickerMode = UIDatePicker.Mode.date }
    func datePickerDefaultDate() { myDatePicker.date = NSDate().xDays(x: +1) as Date              }
    func notificationsOptions()  {
        localNotification.timeZone = NSTimeZone.local
        localNotification.repeatInterval = .CalendarUnitDay
        UIApplication.shared.scheduleLocalNotification(localNotification)
        localNotification.alertAction = "Open App"
        localNotification.alertBody = "Here is the seven o'clock notification"
        localNotification.soundName = UILocalNotificationDefaultSoundName
        localNotification.applicationIconBadgeNumber = UIApplication.shared.applicationIconBadgeNumber + 1
        //     you may add arbitrary key-value pairs to this dictionary.
        //     However, the keys and values must be valid property-list types
        //     if any are not, an exception is raised.
        // localNotification.userInfo = [NSObject : AnyObject]?
    }
    func toggleSwitch(){
        if mySwitch.isOn{
            localNotification.fireDate = myDatePicker.date.fireDate  // combined date = picked Date + 7:00am time
        } else {
            localNotification.fireDate = NSDate(timeIntervalSinceNow: 999999999999) as Date   // will never be fired
        }
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // here is where you place your IBActions
    
    @IBAction func switchPressed(sender: AnyObject) {
        toggleSwitch()
        
    }
    
    public extension NSDate {
        func xDays(x:Int) -> NSDate {
            return NSCalendar.currentCalendar().dateByAddingUnit(.CalendarUnitDay, value: x, toDate: self, options: nil)!
        }
        var day:            Int { return NSCalendar.currentCalendar().components(NSCalendarUnit.CalendarUnitDay,           fromDate: self).day           }
        var month:          Int { return NSCalendar.currentCalendar().components(NSCalendarUnit.CalendarUnitMonth,         fromDate: self).month         }
        var year:           Int { return NSCalendar.currentCalendar().components(NSCalendarUnit.CalendarUnitYear,          fromDate: self).year          }
        var fireDate: NSDate    { return NSCalendar.currentCalendar().dateWithEra(1, year: year, month: month, day: day, hour: 7, minute: 0, second: 0, nanosecond: 0)! }
    }
}
    


