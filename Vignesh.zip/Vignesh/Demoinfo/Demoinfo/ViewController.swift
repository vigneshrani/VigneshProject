//
//  ViewController.swift
//  Demoinfo
//
//  Created by thomas on 21/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var Passwordfild: UITextField!
    @IBOutlet weak var Mobilefield: UITextField!
    @IBOutlet weak var Usernamefield: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        Usernamefield.delegate = self as! UITextFieldDelegate
        Passwordfild.delegate = self as! UITextFieldDelegate
        Mobilefield.delegate = self as! UITextFieldDelegate
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    @IBOutlet weak var Textfield: UITextView!
    
    @IBAction func tap(_ sender: Any) {
        Textfield.text = "User Name: \(Usernamefield.text!)\npassword: \(Passwordfild.text!)\nmobile number: \(Mobilefield.text!)"
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
    Passwordfild.resignFirstResponder()
    }
}
extension ViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Textfield.resignFirstResponder()
        return true
    }
}

