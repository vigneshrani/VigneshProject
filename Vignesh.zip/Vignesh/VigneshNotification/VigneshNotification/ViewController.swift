import UIKit
import UserNotifications
import Foundation


var dateFormatter : DateFormatter!

let change = UIDatePicker();
let date = Date()

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
    
{
    var pickerString = [String]()

    func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        
        return 1
        
    }
    
    func tableView(_ tableView: UITableView!, numberOfRowsInSection section: Int) -> Int {
        return pickerString.count
    }
    
    func tableView(_ tableView: UITableView!, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "id", for: indexPath)
        
        return cell
    }
    
   
    
    @IBOutlet var dateLabel: UILabel!
    
   
    
    @IBAction func change(_ sender : UIDatePicker)
    {
        pickerString = [dateFormatter.string(from: sender.date)]
       
        let nowString = dateFormatter.string(from: Date())
        
        
        
        
    
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Remainder"
        content.body = "vignesh you  set  a  Notification"
        let calendar = Calendar(identifier: .gregorian)
        let components = calendar.dateComponents(in: .current, from: sender.date)
        //        let imageName = "applelogo"
        //        guard let imageURL = Bundle.main.url(forResource: imageName, withExtension: "png") else { return }
        //        print("imageURL",imageURL)
        
        let newComponents = DateComponents(calendar: calendar, timeZone: .current, month: components.month, day: components.day, hour: components.hour, minute: components.minute)
        let trigger = UNCalendarNotificationTrigger(dateMatching: newComponents, repeats: false)
        let request = UNNotificationRequest(identifier: "remainder",content: content, trigger:trigger)
        center.add(request) {(error) in
            if error != nil {
                print("error local notification")
                
            }
        }
        print("cool",sender.date)
        
        print("coolsss",nowString)
        
        
        func viewDidLoad() {
            super.viewDidLoad()
            
            
            
            dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "YYYY-MM-dd hh:mm"
        }
        
    }}


