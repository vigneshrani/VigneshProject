//
//  ViewController.swift
//  Navigation
//
//  Created by thomas on 28/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//    var stringPassed = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBOutlet weak var NameText: UITextField!
    
    @IBAction func OKButton(_ sender: Any) {
        
        let myVC = storyboard?.instantiateViewController(withIdentifier: "ID") as! NameViewController
        myVC.stringPassed = NameText.text!
        navigationController?.pushViewController(myVC, animated: true)
    }
    

}

