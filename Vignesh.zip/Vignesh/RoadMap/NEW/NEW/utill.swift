//
//  utill.swift
//  NEW
//
//  Created by thomas on 01/06/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class utill: NSObject {
    static let appDelegate = UIApplication.shared.delegate as! AppDelegate
class func setLocalNotification(at date: Date, title: String, body: String, id: String) {
    self.appDelegate.scheduleNotification(at: date, title: "Upcoming Medication Remainder", body: "heelp data", id: "da6")
    }
}

