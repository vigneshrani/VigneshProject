
import UIKit
import Foundation

var dateFormatter : DateFormatter!

let datePicker2 = UIDatePicker()
let date = Date()

class ViewController: UIViewController {
    
    @IBOutlet var dateLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let datePicker : UIDatePicker = UIDatePicker(frame: CGRect(x: 0,y: 330,width: self.view.frame.size.width,height: 220))
        datePicker.datePickerMode = UIDatePicker.Mode.dateAndTime
        self.view.addSubview(datePicker)
        
        datePicker.addTarget(self, action: #selector(ViewController.change(_:)), for: UIControl.Event.valueChanged)
        
        dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYY-MM-dd hh:mm"
    }
    
    @IBAction func change(_ sender : UIDatePicker)
    {
        let pickerString = dateFormatter.string(from: sender.date)
        let nowString = dateFormatter.string(from: Date())
         utill.setLocalNotification(at: sender.date, title: "Upcoming Medication Remainder", body: "heelp data", id: "da6")
        dateLabel.text = pickerString
        if pickerString == nowString {
            print("cool")
        }
    }}
