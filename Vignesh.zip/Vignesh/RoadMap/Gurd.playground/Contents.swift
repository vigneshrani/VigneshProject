//func fooBinding(x: Int?) {
//    if let x = x, x > 0 {
//        // Do stuff with x
//        x.description
//    }
//
//    // Value requirements not met, do something
//}
//let a: Int? = 40
//func doSomething(passedA:Int?) {
//    guard var b = passedA else {
//        return
//    }
//    print (b) // prints 40
//    b = 100
//    print (b) // prints 100
//}
//doSomething(passedA: a)
func someFunction() {
    
    guard true else {
        print("Condition not met")
        return
    }
    print("Condition met")
}

someFunction()
print("Hello after function call")
