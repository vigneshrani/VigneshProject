//
//  ViewController.swift
//  New3
//
//  Created by thomas on 01/06/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit
import UserNotifications


class  CreateTaskViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        UIDatePicker.addTarget(self, action: #selector(datePickerselectedDate(_:)), for: .valueChanged)
    }
//    @IBAction func addTapped(_ sender: Any) {
//
//
//        // Create Task from the outlet info
//
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//
//        let task = Task(context: context)
//
//        task.name = taskNameTextField.text!
//        task.important = importantSwitch.isOn
//        (UIApplication.shared.delegate as! AppDelegate).saveContext()
//
//    }
//
    func scheduleNotification(at date: Date) {
        
        let calander = Calendar(identifier: .gregorian)
        let components = calander.dateComponents(in: .current, from: date)
        let newComponents = DateComponents(calendar: calander, timeZone: .current,  month: components.month, day: components.day, hour: components.hour, minute: components.minute)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: newComponents, repeats: false)
        let content = UNMutableNotificationContent()
        content.title = "Reminder!!"
    
        content.sound = UNNotificationSound.default
        
        let request = UNNotificationRequest(identifier: "textNotification", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        UNUserNotificationCenter.current().add(request) {(error) in if let error = error {
            print("Uh oh! we had an error:\(error)")
            
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge ], completionHandler: {didAllow, error in })
            }
            func datePickerselectedDate(_ sender: UIDatePicker) {
                
                self.scheduleNotification(at : sender.date)
                
            }

}

}
}
