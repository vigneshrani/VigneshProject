//
//  CollectionViewCell.swift
//  Tab
//
//  Created by thomas on 29/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    var stringPassed = ""
    
    @IBOutlet weak var CollectionView: UICollectionView!
    @IBOutlet weak var Label: UILabel!
    
 
}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell = ViewController.dequeueReusableCell(withReuseIdentifier: "ID", for: indexPath) as? ViewController
        cell?.Ftext.text! = stringPassed
        return cell
    }
    
}
