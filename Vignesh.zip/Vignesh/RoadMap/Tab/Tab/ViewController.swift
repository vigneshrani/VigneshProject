//
//  ViewController.swift
//  Tab
//
//  Created by thomas on 29/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var imaarr = [""]
    var stringPassed = ""
    @IBOutlet weak var FText: UITextField!
    
    @IBOutlet weak var Stext: UITextField!
    @IBOutlet weak var Ttext: UITextField!
    @IBOutlet weak var Ftext: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func SaveButton(_ sender: Any) {
    
        let myVC = storyboard?.instantiateViewController(withIdentifier: "IDI") as! CollectionViewCell
        myVC.stringPassed = FText.text!
        
        navigationController?.pushViewController( <#UIViewController#>, animated: true)
        
        }
        }
        





