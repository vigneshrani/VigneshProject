//
//  ViewController.swift
//  TableVig
//
//  Created by thomas on 28/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ID") as! SEViewController
        // Configure YourCustomCell using the outlets that you've defined.
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt cellForRowAtindexPath: IndexPath) -> UITableViewCell {
        cell.textLabel?.text = "This is row \(IndexPath.row)"
        
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    



}

