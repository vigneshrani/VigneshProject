import UIKit
import EventKit

class RemindersViewController: UIViewController {
    func scheduleNotification(date:String , time: String , subject:String) {
        
        var dateString = date+" "+time
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
        
        let convertedDate = dateFormatter.date(from: dateString)!
        
        let subtractTime = Calendar.current.date(byAdding: .minute, value: -10, to: convertedDate)
        
        dateString = dateFormatter.string(from: subtractTime!)
        
        var localTimeZoneName: String { return TimeZone.current.identifier }
        var secondsFromGMT: Int { return TimeZone.current.secondsFromGMT() }
        dateFormatter.timeZone = TimeZone(secondsFromGMT: secondsFromGMT)
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
        
        let dateObj:Date = dateFormatter.date(from: dateString)!
        
        print("alaram time  : \(dateObj)")
        
        let triggerDaily = Calendar.current.dateComponents([.day,.month,.year,.hour,.minute,], from: dateObj)
        
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDaily, repeats: true)
        
        let alarmId = UUID().uuidString
        
        let content = UNMutableNotificationContent()
        content.title = "your title"
        content.body = subject
        content.sound = UNNotificationSound.init(named: "your sound filename.mp3")
        content.categoryIdentifier = alarmId
        
        let request = UNNotificationRequest(identifier: alarmIdentifier, content: content, trigger: trigger)
        
        print("alarm identi   : \(alarmIdentifier)")
        
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().add(request) {(error) in
            
            if let error = error {
                print("Uh oh! i had an error: \(error)")
            }
        }
    }`   
}
