//
//  ViewController.swift
//  NEW1
//
//  Created by thomas on 01/06/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var datePicker: UIDatePicker!
    @IBOutlet var notificationSwitch: UISwitch!
    
    let localNotification = UILocalNotification()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNotificationsOptions()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func setUpNotificationsOptions()  {
        datePicker.datePickerMode = .time
        localNotification.timeZone = NSTimeZone.local
        localNotification.repeatInterval = .day
        localNotification.alertAction = "Open App"
        localNotification.alertBody = "a notification"
        localNotification.soundName = UILocalNotificationDefaultSoundName
    }
    
    func toggleNotification() {
        if notificationSwitch.isOn {
            localNotification.fireDate = datePicker.date.fireDate
            UIApplication.shared.scheduleLocalNotification(localNotification)
        } else {
            localNotification.fireDate = nil
            UIApplication.shared.cancelLocalNotification(localNotification)
        }
    }
    @IBAction func toggleSwitch(sender: UISwitch) {
        toggleNotification()
    }
    @IBAction func dateChanged(sender: UIDatePicker) {
        toggleNotification()
    }
}
extension NSDate {
    var minute: Int {
        return NSCalendar.currentCalendar.component(.Minute, fromDate: self)
    }
    var hour: Int {
        return NSCalendar.currentCalenda.component(.Hour, fromDate: self)
    }
    var day: Int {
        return NSCalendar.currentCalenda.component(.Day, fromDate: self)
    }
    var month: Int {
        return NSCalendar.currentCalenda.component(.Month, fromDate: self)
    }
    var year: Int {
        return NSCalendar.currentCalenda.component(.Year, fromDate: self)
    }
    var fireDate: NSDate {
        let today = NSDate()
        return NSCalendar.currentCalenda.dateWithEra(1,
                                                        year: today.year,
                                                        month: today.month,
                                                        day: { hour > today.hour || (hour  == today.hour
                                                            &&  minute > today.minute) ? today.day : today.day+1 }(),
                                                        hour: hour,
                                                        minute: minute,
                                                        second: 0,
                                                        nanosecond: 0
            )!
    }
}






