import UIKit
import Foundation
enum Student {
   case Name(String)
   case Mark(Int,Int,Int)
}
var studName = Student.Name("swifty")
var studMarks = Student.Mark(98,97,95)
switch studName {
   case .Name:
      print("Student name is")
   case .Mark(let Mark1, let Mark2, let Mark3):
      print("Student Marks are: \(Mark1),\(Mark2),\(Mark3).")
   default:
      print("Nothing")
}

var name: String? = "Bob"
let unwrappedName: String = name!
print("Unwrapped name: \(unwrappedName)")


//var mealPreference: String? = "Vegetarian"
//if mealPreference != nil {
//    let unwrappedMealPreference: String = mealPreference!
//    print("Meal: \(unwrappedMealPreference)") // or do something useful
//}


var mealPreference: String? = "Vegetarian"
if let unwrappedMealPreference: String = mealPreference {
    print("Meal: \(unwrappedMealPreference)")
}

var Name: String? = "vignesh"
if let unWrap: String = Name{
print("Name: \(unWrap)")
}
