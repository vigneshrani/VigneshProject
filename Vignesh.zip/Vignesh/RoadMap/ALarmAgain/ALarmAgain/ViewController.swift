import UIKit
import UserNotifications
var dateFormatter : DateFormatter!

let datePicker = UIDatePicker();
let date = Date()


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var table: UITableView!
    
    @IBOutlet weak var date: UIDatePicker!
    
    var pickerString = [String]()
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // Return the number of sections.
        
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pickerString.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = pickerString[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       

          print("dratra",pickerString[indexPath.row])
    }

     func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete {
          pickerString.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
    }
//    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
//
//        let editAction = UITableViewRowAction(style: .normal, title: "Edit") { (rowAction, indexPath) in
//            //TODO: edit the row at indexPath here
//            print("hi")
//
//            //tableView.insertRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
//        }
//        editAction.backgroundColor = .blue
//
//        let deleteAction = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
//            //TODO: Delete the row at indexPath here
//            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
//        }
//        deleteAction.backgroundColor = .red
//
//        return [editAction,deleteAction]
//    }
    
    
    @IBOutlet var dateLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "YYYY-MM-dd hh:mm"
    }
    
    
    @IBAction func Save(_ sender: Any) {
        
    
    
       
      
        let dateString = dateFormatter.string(from: date.date)
        // put the string in the data source for the table
        pickerString.insert(dateString, at: 0)
        table.reloadData()
        let indexPathRow:Int = 0
        let indexPosition = IndexPath(row: indexPathRow, section: 0)
         table.reloadRows(at: [indexPosition], with: .none)
        
        

        // profit?
//        pickerString = [dateFormatter.string(from: sender.date)]
        let nowString = dateFormatter.string(from: Date())
        
//        dateLabel.text = pickerString
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Remainder"
        content.body = "vignesh you  set  a  Notification"
        let calendar = Calendar(identifier: .gregorian)
        let components = calendar.dateComponents(in: .current, from: date.date)
        //        let imageName = "applelogo"
        //        guard let imageURL = Bundle.main.url(forResource: imageName, withExtension: "png") else { return }
        //        print("imageURL",imageURL)
        
        let newComponents = DateComponents(calendar: calendar, timeZone: .current, month: components.month, day: components.day, hour: components.hour, minute: components.minute)
        let trigger = UNCalendarNotificationTrigger(dateMatching: newComponents, repeats: false)
        let request = UNNotificationRequest(identifier: dateString,content: content, trigger:trigger)
        center.add(request) {(error) in
            if error != nil {
                print("error local notification")
                
            }
        }
            print("cool",date.date)
         
         print("coolsss",nowString)
        
        
       
        }
    }
