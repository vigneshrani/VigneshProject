//
//  DateUtils.swift
//  Aerobit
//
//  Created by Sakthikumar on 2/18/18.
//  Copyright © 2018 Sakthikumar. All rights reserved.
//

import UIKit

class DateUtils: NSObject {
        
    // MARK:- Get years from 1970 to Till Now
    class func yearsTillNow(fromYear: Int = 2004) -> [String] {
        var years = [String]()
        (1900...fromYear).reversed().forEach({ years.append("\($0)") })
        return years
    }
    
    class func dateStringFromDateObject(date: Date?, format: DateFormate, timeZone: TimeZone = TimeZone(abbreviation: "UTC")!) -> String? {
        guard let date = date else { return nil }
        
        let dateFormatter = DateFormatter()
//        dateFormatter.locale = Locale(identifier: "en_US")
        dateFormatter.timeZone = timeZone
        dateFormatter.dateFormat = format.rawValue
        return dateFormatter.string(from: date)
    }
    
    class func dateObjectFromDateString(dateString: String?, format: DateFormate) -> Date? {
        guard let dateString = dateString else { return nil }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format.rawValue
//        dateFormatter.locale = Locale(identifier: "en_US")
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        return dateFormatter.date(from: dateString)
    }
    
    class func dateObjectFromDateStringTimeZone(dateString: String?, format: DateFormate, timeZone: TimeZone = TimeZone(abbreviation: "UTC")!) -> Date? {
        guard let dateString = dateString else { return nil }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format.rawValue
        dateFormatter.timeZone = timeZone
        return dateFormatter.date(from: dateString)
    }
    
    class func getMillisecondsFromDate(date: Date) -> Int {
        return Int((date.timeIntervalSince1970 * 1000.0).rounded())
    }
    
    class func getDateFromMilliseconds(milliseconds: Int) -> Date {
        return Date(timeIntervalSince1970: TimeInterval(milliseconds / 1000))
    }
    
    class func convertToLocalTimeZone(date: Date?, format: DateFormate) -> String? {
        guard let date = date else { return nil }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format.rawValue
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        return dateFormatter.string(from: date)
    }
    
    class func convertToLocalTimeZoneDate(dateString: String?, format: DateFormate) -> Date? {
        guard let dateString = dateString else { return nil }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format.rawValue
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT+0:00")
        return dateFormatter.date(from: dateString)
    }
    
    class func localToUTC(date:String, fromFormat: DateFormate, toFormat: DateFormate) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = fromFormat.rawValue
        dateFormatter.calendar = NSCalendar.current
        dateFormatter.timeZone = TimeZone.current
        
        let dt = dateFormatter.date(from: date)
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.dateFormat = toFormat.rawValue
        
        return dateFormatter.string(from: dt!)
    }
    
    class func UTCToLocal(date:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "H:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        let dt = dateFormatter.date(from: date)
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "dd-MMM-yyyy hh:mm a"
        
        return dateFormatter.string(from: dt!)
    }
    
    class func convertDateStringFormates(dateString: String, fromFormat: DateFormate, toFormat: DateFormate) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = fromFormat.rawValue
        dateFormatter.locale = Locale(identifier: "en_US")
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        guard let dt = dateFormatter.date(from: dateString) else { return "" }
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = toFormat.rawValue
        dateFormatter.locale = Locale(identifier: "en_US")
        
        return dateFormatter.string(from: dt
        )
    }
    
    class func getDashboardTitleDayString(date: Date) -> String {
        if date.isToday() {
            return "Today"
        } else if date.isYesterday() {
            return "Yesterday"
        } else {
            return DateUtils.dateStringFromDateObject(date: date, format: .mainDayFormat) ?? ""
        }
    }
    
    class func mergeDateWithTime(timeString: String?, fromDate: Date) -> Date? {
        guard let timeString = timeString else { return nil }
        let currentDate = DateUtils.dateStringFromDateObject(date: fromDate, format: .thirdMainDateFormat)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy hh:mm a"
        dateFormatter.locale = Locale(identifier: "en_US")
        var time = ""
        if timeString.count > 8 {
            time = String(timeString.dropFirst(11) )
        } else {
            time = timeString
        }
        return dateFormatter.date(from: "\(currentDate!) \(time)")
    }
    
    class func mergeDateWithTimeFormat(timeString: String?, fromDate: Date) -> Date? {
        guard let timeString = timeString else { return nil }
        let currentDate = DateUtils.dateStringFromDateObject(date: fromDate, format: .thirdMainDateFormat)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MMM-yyyy HH:mm:ss"
        dateFormatter.locale = Locale(identifier: "en_US")
        return dateFormatter.date(from: "\(currentDate!) \(timeString)")
    }
}

extension Date {
    func getDateOnly() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd"
        return dateFormatter.string(from: self)
    }
    
    func getDateString(format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
    
    func getDateStringWithTimeZone(format: String, timeZone: TimeZone = TimeZone(abbreviation: "UTC")!) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = timeZone
        return dateFormatter.string(from: self)
    }
    
    func removeSeconds() -> Date {
        let timeInterval = floor(self.timeIntervalSinceReferenceDate / 60.0) * 60.0
        return Date(timeIntervalSinceReferenceDate: timeInterval)
    }
    
    func add(minutes: Int) -> Date {
        return Calendar(identifier: .gregorian).date(byAdding: .minute, value: minutes, to: self)!
    }
    
    func add(day: Int) -> Date {
        return Calendar(identifier: .gregorian).date(byAdding: .day, value: day, to: self)!
    }
    
    func minutes(from date: Date) -> Int {
        return Calendar.current.dateComponents([.minute], from: date, to: self).minute ?? 0
    }
    
    func seconds(from date: Date) -> Int {
        print(Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0)
        return Calendar.current.dateComponents([.second], from: date, to: self).second ?? 0
    }
    
    func isToday() -> Bool {
        if let activeDate = DateUtils.dateStringFromDateObject(date: self, format: .mainDateFormat, timeZone: .current), let todayDate = DateUtils.dateStringFromDateObject(date: Date(), format: .mainDateFormat), activeDate == todayDate {
            return true
        }
        
        return false
    }
    
    func isPastDay() -> Bool {
        if let activeDate = DateUtils.dateStringFromDateObject(date: self, format: .mainDateFormat), let todayDate = DateUtils.dateStringFromDateObject(date: Date(), format: .mainDateFormat), activeDate <  todayDate {
            return true
        }
        
        return false
    }
    
    func isYesterday() -> Bool {
        if let activeDate = DateUtils.dateStringFromDateObject(date: self, format: .mainDateFormat), let yesterdayDate = DateUtils.dateStringFromDateObject(date: Date().add(day: -1), format: .mainDateFormat), activeDate == yesterdayDate {
            return true
        }
        
        return false
    }
    
    // Convert local time to UTC (or GMT)
    func toGlobalTime() -> Date {
        let timezone = TimeZone.current
        let seconds = -TimeInterval(timezone.secondsFromGMT(for: self))
        return Date(timeInterval: seconds, since: self)
    }
    
    // Convert UTC (or GMT) to local time
    func toLocalTime() -> Date {
        let timezone = TimeZone.current
        let seconds = TimeInterval(timezone.secondsFromGMT(for: self))
        return Date(timeInterval: seconds, since: self)
    }
    
    // Comparison
    func isSameDate(_ comparisonDate: Date) -> Bool {
        let order = Calendar.current.compare(self, to: comparisonDate, toGranularity: .day)
        return order == .orderedSame
    }
    
    init?(_ year: Int,_ month: Int,_ day: Int) {
        guard let date = DateComponents(calendar: .current, year: year, month: month, day: day, hour: 12).date else { return nil }
        self = date
    }
}


//
extension Date {
    struct Formatter {
        static let utcFormatter: DateFormatter = {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm'Z'"
            dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
            return dateFormatter
        }()
    }
    
    var dateToUTC: String {
        return Formatter.utcFormatter.string(from: self)
    }
}


extension String {
    struct Formatter {
        static let utcFormatter: DateFormatter = {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            return dateFormatter
        }()
    }
    
    var dateFromUTC: Date? {
        return Formatter.utcFormatter.date(from: self)
    }
}
