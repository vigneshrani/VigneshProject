//
//  ViewController.swift
//  VigDes
//
//  Created by thomas on 22/05/19.
//  Copyright © 2019 thomas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func SinginB(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "SID") as? SViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

